import requests
import json
import pandas as pd
import boto3
import logging
from io import StringIO
import consonants as constant

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize AWS clients
ssm = boto3.client("ssm", region_name="eu-north-1")
sns = boto3.client("sns", region_name="eu-north-1")
s3 = boto3.client('s3')

def get_ssm_parameter(name, decrypt=True):
    """Retrieve a parameter from AWS SSM."""
    try:
        return ssm.get_parameter(Name=name, WithDecryption=decrypt)["Parameter"]["Value"]
    except Exception as e:
        logger.error(f"Error fetching SSM parameter {name}: {str(e)}", exc_info=True)
        raise

def send_sns_notification(topic_arn, message, subject):
    """Send an SNS notification."""
    try:
        response = sns.publish(TargetArn=topic_arn, Message=json.dumps({'default': message}), Subject=subject, MessageStructure="json")
        logger.info(f"SNS notification sent: {message}")
        return response
    except Exception as e:
        logger.error(f"Failed to send SNS notification: {str(e)}", exc_info=True)

def save_to_s3(df, bucket_name, s3_path):
    """Save DataFrame to S3 as CSV."""
    try:
        csv_buffer = StringIO()
        df.to_csv(csv_buffer, header=True, index=False)
        s3.put_object(Bucket=bucket_name, Key=s3_path, Body=csv_buffer.getvalue())
        return f"s3://{bucket_name}/{s3_path}"
    except Exception as e:
        logger.error(f"Error saving to S3: {str(e)}", exc_info=True)
        raise

def fetch_and_process_data():
    """Fetch CSV files from URL, process and return the final DataFrame."""
    try:
        url = get_ssm_parameter(constant.urlapi)
        response = requests.get(url)
        files = response.json()
        
        csv_files = [file['download_url'] for file in files if file['name'].endswith('.csv')]
        base_df = pd.read_csv(csv_files.pop())
        
        dataframes = [pd.read_csv(url).assign(Symbol=url.split("/")[-1].replace(".csv", "")) for url in csv_files]
        combined_df = pd.concat(dataframes, ignore_index=True)
        
        merged_df = pd.merge(combined_df, base_df, on='Symbol', how='left')
        merged_df["timestamp"] = pd.to_datetime(merged_df["timestamp"])
        
        filtered_df = merged_df[(merged_df['timestamp'] >= "2021-01-01") & (merged_df['timestamp'] <= "2021-05-26")]
        result_df = filtered_df.groupby("Sector").agg({'open':'mean','close':'mean','high':'max','low':'min','volume':'mean'}).reset_index()
        
        return result_df[result_df["Sector"].isin(["TECHNOLOGY", "FINANCE"])].reset_index(drop=True)
    except Exception as e:
        logger.error(f"Error processing data: {str(e)}", exc_info=True)
        send_sns_notification(get_ssm_parameter(constant.ERRORNOTIFICATIONARN), "Data processing failed", "Error Notification")
        raise

def lambda_handler(event, context):
    """AWS Lambda handler function."""
    try:
        df = fetch_and_process_data()
        bucket_name = 'rohith-264'
        s3_path = 'output/result.csv'
        save_to_s3(df, bucket_name, s3_path)
        send_sns_notification(get_ssm_parameter(constant.SUCCESSNOTIFICATIONARN), "Data successfully processed", "Success Notification")
        
        return {'statusCode': 200, 'body': json.dumps(f'Data saved to {bucket_name}/{s3_path}')}
    except Exception as e:
        return {'statusCode': 500, 'body': json.dumps(f'Error: {str(e)}')}
